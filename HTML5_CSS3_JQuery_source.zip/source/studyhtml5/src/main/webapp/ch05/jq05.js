$(document).ready(function(){
	$(document).keypress(function(){//웹페이지에서 키보드를 눌렀다 놓으면 발생
		$("#p1").css("color","blue");
	})
});