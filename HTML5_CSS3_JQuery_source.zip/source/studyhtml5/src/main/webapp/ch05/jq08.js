$(document).ready(function(){
	//[결과]버튼을 클릭하면 jq02.html페이지가 실행된다.
	$("#pro").click(function(){
	   $("#result").load("jq02.html");
	});
});